#!/usr/bin/env bash

sudo apt update
sudo apt install -y openjdk-17-jdk maven git wget htop lbzip2 python3